# CHANGELOG.md

## [1.4.3] - 2023-04-11

- Update dependencies

## [1.4.2] - 2023-02-13

- Update dependencies
- Improve sidebar icons color logic

## [1.4.0] - 2022-08-30

- Update sidebar

## [1.3.0] - 2022-07-15

- Replace Sass with CSS files
- Update dependencies

## [1.1.0] - 2021-12-13

- Update Tailwind 3
- Several improvements

## [1.0.3] - 2021-12-10

- Alignment issue

## [1.0.2] - 2021-11-23

- Alignment issue

## [1.0.1] - 2021-11-22

Fix dashboard icon color

## [1.0.0] - 2021-11-22

First release